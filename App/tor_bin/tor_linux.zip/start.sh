#!/bin/bash
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
LD_LIBRARY_PATH=${DIR}
export LD_LIBRARY_PATH
$LD_LIBRARY_PATH/tor &>/dev/null &
